#ifndef FUNCTION_H
#define FUNCTION_H

#include <iostream>
#include <fstream>
using namespace std;

char* readConfigFile(const char * cfgfilepath, char*  key)//��ȡ�����ļ�
{
	int position=0;//�Ⱥ�λ���±�
    fstream cfgFile;
    cfgFile.open(cfgfilepath);//���ļ�	
    if( ! cfgFile.is_open())
    {
        cout<<"can not open cfg file!"<<endl;
        return false;
    }
    char tmp[1000];
    while(!cfgFile.eof())//ѭ����ȡÿһ��
    {
        cfgFile.getline(tmp,1000,'\n');//ÿ�ж�ȡǰ1000���ַ���1000��Ӧ���㹻��
        int len = strlen(tmp);
		if(tmp[0]=='#')
		{
			cfgFile.eof();
			cfgFile.getline(tmp,1000,'\n');
			len = strlen(tmp);
		}
		for(int i=0;i<len;i++)//Ѱ�ҵȺ�
		{
			if(tmp[i]=='=')
			{
				position=i;
			}
		}
		if(position==0)//��Ч�д���
			return false;
		char *tmpkey=new char[position];// = "order_num";//�ؼ���
		for(int i=0;i<position;i++)
		{
			tmpkey[i]='\0';
		}
		for(int i=0;i<position;i++)
		{
			tmpkey[i]=tmp[i];
			tmpkey[i+1]='\0';
		}
		if( strcmp(key,tmpkey)==0 )//��ȡ=��֮���ֵ
		{
			int j=0;
			char *value=new char[len-position-1];
			for(int i=0;i<len-position-1;i++)
			{
				value[i]='\0';
			}
			for(int i=position+1;i<len;i++)
			{
				value[j]=tmp[i];
				value[j+1]='\0';
				j++;
			}
			return value;
		}
    }
	return NULL;
}



#endif