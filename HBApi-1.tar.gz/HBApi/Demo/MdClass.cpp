
#include "stdafx.h"
extern char *BROKER_ID;
extern char *USER_MD;
extern char *PASSWORD_MD;
extern char *FRONT_ADDR_MD;
extern bool MD_CON_STA;
extern HANDLE g_hEvent;
extern char *cInstrumentID[12000];
extern int InsCont;
map <string, CSecurityFtdcDepthMarketDataField> mdmap;
extern int SufCont;
CRITICAL_SECTION g_cs;
int ct=0;
int errorcnt=0;

MdClass::MdClass()
{
	//cout<<"Level1 API init-----------------------begin!"<<endl;
	pMD=CSecurityFtdcMdApi::CreateFtdcMdApi("comm/md");
	//cout<<"Create api"<<endl;
	pMD->RegisterSpi(this);
	//cout<<"RegisterFront address"<<endl;
	pMD->RegisterFront(FRONT_ADDR_MD);
	//cout<<"Front Address:"<<FRONT_ADDR_MD<<endl;
	pMD->Init();
	//cout<<"Init Level2 Api"<<endl;
	//cout<<"Init Level2 Api-----------------------end!"<<endl;
	strcpy_s(LoginInfo.BrokerID,BROKER_ID);
	strcpy_s(LoginInfo.UserID,USER_MD);
	strcpy_s(LoginInfo.Password,PASSWORD_MD);
	//cout<<"Please enter the cipher of the Level1 Account��"<<endl;
	////�����¼���̣������ӿ�->ע��ǰ�û�->���÷����û���¼��Ϣ->��¼�ɹ���ʧ����Ϣ����
}

void MdClass::choice()
{
	int ch2=0;
	
	char *temp;
	char **InstrumentID;
	temp=new char[10];
	
	do{
		WaitForSingleObject(g_hEvent, 5000);
		cout<<"Level1 Choice of Menu--------------------------"<<this->pMD->GetTradingDay()<<"-----------------------------"<<endl;
		cout<<"1:Subscribe Stock and Index"<<endl;
		cout<<"2:Unsubscribe All"<<endl;
		//cout<<"3:Look at the return on the bulk of level1 data"<<endl;
		cout<<"0:Previous Menu"<<endl;
		cin>>ch2;
		switch(ch2)
		{
		case 1:cout<<"Subscribe to Quotations"<<endl;
			cin>>temp;
			InstrumentID=&temp;
			//mdmap.clear();
			//cout<<cInstrumentID[0]<<endl;
			//cout<<cInstrumentID[1]<<endl;
			system("PAUSE");
			this->pMD->SubscribeMarketData(InstrumentID,1,"HGE");
			ResetEvent(g_hEvent);
			break;
		case 2:cout<<"Unsubscribe all"<<endl;
			cin>>temp;
			
			InstrumentID=&temp;
			system("PAUSE");
			//mdmap.clear();
			this->pMD->UnSubscribeMarketData(InstrumentID,1,"SSE");
			ct=0;
			errorcnt=0;
			SufCont=0;
			ResetEvent(g_hEvent);
			break;
		case 3:cout<<"Quotations that have been subscribed:"<<endl;
			   //cout<<"Numbers��"<<ct<<" Successful:"<<mdmap.size()<<" Failed:"<<errorcnt<<endl;
			   //Viewmap();
			break;
		default:break;
		
		}
	}while(ch2!=0);
}


void MdClass::Viewmap()
{
	map <string, CSecurityFtdcDepthMarketDataField>::iterator mdit;
	//EnterCriticalSection(&g_cs);
	mdit=mdmap.begin();
	for(mdit=mdmap.begin();mdit!=mdmap.end();mdit++)
	{
		//cout<<"Symbol:"<<mdit->second.InstrumentID<<" Status:"<<mdit->second.TradingPhase<<endl;
	}
	//LeaveCriticalSection(&g_cs);
	cout<<"It's End"<<endl;
}


void MdClass::OnFrontConnected()
{

	//cout<<"Connect to level1 front success��"<<endl;
	int ReqCode=0;
	ReqCode=pMD->ReqUserLogin(&LoginInfo,1);
	//cout<<"User login-----------------------begin!"<<endl;
	//cout<<"User ID:"<<USER_MD<<endl;
	//cout<<"Broker ID:"<<BROKER_ID<<endl;
	//cout<<"User login return code:"<<ReqCode<<endl;
}

void MdClass::OnFrontDisconnected(int nReason)
{
	cout<<"Level1 front Disconnected!"<<endl;

}

void MdClass::OnHeartBeatWarning(int nTimeLapse)
{


}

void MdClass::OnRspError(CSecurityFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{


}

void MdClass::OnRspUserLogin(CSecurityFtdcRspUserLoginField *pRspUserLogin, CSecurityFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	if(pRspInfo->ErrorID==0)
	{
		cout<<"Level1 login success!"<<endl;
		MD_CON_STA=true;
	}
	else
	{
		cout<<"Level1 login failed!"<<endl;
		cout<<"Login status return code:"<<pRspInfo->ErrorMsg<<endl;
	}

}


void MdClass::OnRspUserLogout(CSecurityFtdcUserLogoutField *pUserLogout, CSecurityFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{


}

void MdClass::OnRspSubMarketData(CSecurityFtdcSpecificInstrumentField *pSpecificInstrument, CSecurityFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	if(pRspInfo!=NULL&&pSpecificInstrument!=NULL)
	{
		cout<<"Subscriptions---------------------------:"<<pSpecificInstrument->InstrumentID<<"|"<<pRspInfo->ErrorMsg<<" msgid:"<<pRspInfo->ErrorID<<endl;

	}
		

}

void MdClass::OnRspUnSubMarketData(CSecurityFtdcSpecificInstrumentField *pSpecificInstrument, CSecurityFtdcRspInfoField *pRspInfo, int nRequestID, bool bIsLast)
{
	if(pSpecificInstrument!=NULL)
	cout<<"Unsubscribe success---------------------------Symbol:"<<pSpecificInstrument->InstrumentID<<endl;
	SetEvent(g_hEvent);
}




void MdClass::OnRtnDepthMarketData(CSecurityFtdcDepthMarketDataField *pDepthMarketData)
{
	//char temp1[31];
	//string ac("");
	if(pDepthMarketData!=NULL)
	{
		//strcpy(temp1,pDepthMarketData->InstrumentID);
		//ac=temp1;
		//mdmap[ac];
		//cout<<ac<<endl;
		//temp1=pDepthMarketData->InstrumentID;
		
		//if(mdmap.find(ac)==mdmap.end())
		//EnterCriticalSection(&g_cs);
		//mdmap[ac]=*pDepthMarketData;
		//LeaveCriticalSection(&g_cs);
		cout<<" Symbol:"<<pDepthMarketData->InstrumentID<<" LastPrice:"<<pDepthMarketData->LastPrice<<" Position:"<<pDepthMarketData->OpenInterest<<endl;
		cout<<"TradingDay:"<<pDepthMarketData->TradingDay<<" Symbol:"<<pDepthMarketData->InstrumentID<<" ExchangeID:"<<pDepthMarketData->ExchangeID<<endl;
		cout<<"Contract on the Exchange:"<<pDepthMarketData->ExchangeInstID<<" LastPrice:"<<pDepthMarketData->LastPrice<<" PreSettlementPrice:"<<pDepthMarketData->PreSettlementPrice<<endl;
		cout<<"PreClosePrice:"<<pDepthMarketData->PreClosePrice<<" PrePosition:"<<pDepthMarketData->PreOpenInterest<<" OpenPrice:"<<pDepthMarketData->OpenPrice<<endl;
		cout<<"HighestPrice:"<<pDepthMarketData->HighestPrice<<" LowestPrice:"<<pDepthMarketData->LowestPrice<<" Volume:"<<pDepthMarketData->Volume<<endl;
		cout<<"TurnOver:"<<pDepthMarketData->Turnover<<" Position:"<<pDepthMarketData->OpenInterest<<" ClosePrice:"<<pDepthMarketData->ClosePrice<<endl;
		cout<<"SettlementPrice:"<<pDepthMarketData->SettlementPrice<<" UpperLimitPrice:"<<pDepthMarketData->UpperLimitPrice<<" LowerLimitPrice:"<<pDepthMarketData->LowerLimitPrice<<endl;
		//cout<<"Infomation----------------------------------------------��end!"<<endl;
		//SetEvent(g_hEvent);
	}
}

MdClass::~MdClass()
{
	pMD->Release();
}