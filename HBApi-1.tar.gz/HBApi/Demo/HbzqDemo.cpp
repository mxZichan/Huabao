// HbzqDemo.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"

#pragma comment(lib,"../Level2/L2mduserapi.lib")
#pragma comment(lib,"../Level1/securitymduserapi.lib")
#pragma comment(lib,"../Trade&Query/securitytraderapi.lib")
#pragma comment(lib,"../Trade&Query/securityqueryapi.lib")


using namespace std;
using namespace _LTS_;

char *FRONT_ADDR_TD="tcp://211.144.195.163:54505";//Trade Front
char *FRONT_ADDR_QRY="tcp://211.144.195.163:54506";//Query Front

char *FRONT_ADDR_MD="tcp://10.200.66.11:24513";//Level1 Front
char *FRONT_ADDR_MDL2="tcp://10.200.66.18:8800";//Level2 Front

char *BROKER_ID="2011";//Broker ID

char *USER_TD="admin";//Trade Account
char *USER_QR="admin";//Query Account
char *USER_MD="admin";//Level1 Account
char *USER_MDL2="admin";//Level2 Account

char *PASSWORD_TD=new char[sizeof(_LTS_::TSecurityFtdcPasswordType)];
char *PASSWORD_QR=new char[sizeof(_LTS_::TSecurityFtdcPasswordType)];
char *PASSWORD_MD=new char[sizeof(_LTS_::TSecurityFtdcPasswordType)];
char *PASSWORD_MDL2=new char[sizeof(_LTS_::TSecurityFtdcPasswordType)];

char *AUTH_CODE="N3EHKP4CYHZGM9VJ";//Client Authentication code: N3EHKP4CYHZGM9VJ

char *USR_PROINFO="LTS-Test";//Authentication Client: LTS-Test
char *INVESTOR_ID="110000001996";//Investor Account
HANDLE g_hEvent= CreateEvent(NULL, true, true, NULL);

bool TR_CON_STA=false;  //Trade configuration login successful markup
bool QR_CON_STA=false;  //Query configuration login successful markup
bool MD_CON_STA=false;  //Level1 configuration login successful markup
bool L2MD_CON_STA=false;//Level2 configuration login successful markup
map <int, CSecurityFtdcOrderField> orderinfo;
//map <TSecurityFtdcInstrumentIDType, CSecurityFtdcDepthMarketDataField> mdmap;//���ĵ�����map
char *cInstrumentID[12000]={0};
int InsCont=0;
int SufCont=0;

//Login password hidden function
int EntPwd(char * pass,const int contn)
{
	char b[256];
	memset(b,0,sizeof(b));
	char c;
	int i=0;
	while((c=getch())!='\r'&&i!=contn)
	{
		b[i]=c;
		i++;
	}
	char *a=b;
	if(i>=contn)
	{
		cout<<"Input length exceeds limit��"<<endl;
		return 1;
	}
	else
	{
		strcpy(pass,a);
	}
	
	return 0;

}
//Transaction, inquiry, market cipher parameter configuration
int init()
{
	int recode=0;

	cout<<"Please enter the Trade password��"<<endl;
	recode+=EntPwd(PASSWORD_TD,sizeof(_LTS_::TSecurityFtdcPasswordType));

	cout<<"Please enter the Query password��"<<endl;
	recode+=EntPwd(PASSWORD_QR,sizeof(_LTS_::TSecurityFtdcPasswordType));

	cout<<"Please enter the Level1 password��"<<endl;
	recode+=EntPwd(PASSWORD_MD,sizeof(_LTS_::TSecurityFtdcPasswordType));

	cout<<"Please enter the Level2 password��"<<endl;
	recode+=EntPwd(PASSWORD_MDL2,sizeof(_LTS_::TSecurityFtdcPasswordType));

	if(recode!=0)
		cout<<"Password input anomaly��"<<endl;
	return recode;

}

int main( )
{
	int ch;
	bool flagt=false;
	int rscode=0;
	int rpass=0;
	int lv2=0;
	cout<<"HB LTS Demo -------------------------------------------------------��"<<endl;

	do{
		rscode=init();//Input password
		cout<<"Whether or not to retry the password��1:yes 0:no"<<endl;
		cin>>rpass;
	}while(rpass!=0);



	if(rscode==0)
	{
		Query *cpQR=new Query;//Invocation of constructor initialization Query API, callback function and front machine configuration
		//Sleep(2000);
		Trader *cpTD=new Trader;//Invocation of constructor initialization Trade API, callback function and front machine configuration
		//Sleep(2000);
		MdClass *cpMd=new MdClass;//Invocation of constructor initialization Level1 API, callback function and front machine configuration
		//Sleep(2000);
		Lv2MD *cpLv2Md=new Lv2MD;//Invocation of constructor to initialization Level2 API, callback function and front machine configuration
		for(int i=0;i<20;i++)
		{
			if(TR_CON_STA==true&&QR_CON_STA==true)//&&MD_CON_STA==true)
			{

				cout<<"Init successfully!"<<endl;
				flagt=true;
				break;
			}
			Sleep(2000);
		
		}


		if(flagt==true)
		{
			do
			{
			cout<<"Please select the required operations-------------------------------------------------"<<endl;
			cout<<"1:Query"<<endl;
			cout<<"2:Trade"<<endl;
			cout<<"3:Level1"<<endl;
			if(L2MD_CON_STA==true)
				cout<<"4:Level2"<<endl;
			else
				cout<<"Level2 no logon"<<endl;
			cout<<"0:exit"<<endl;
			cin>>ch;
			switch(ch)
			{
				case 1:cpQR->choice(); //Query menu
					break;
				case 2:cpTD->choice();//Trade menu
					break;
				case 3:cpMd->choice();//Level1 menu
					break;
				case 4:if(L2MD_CON_STA==true)
						cpLv2Md->choice();//Level2 menu
					break;
				case 0:delete cpQR;
					delete cpTD;
					delete cpMd;
					if(L2MD_CON_STA==true)
						delete cpLv2Md;
					Sleep(3000);
					break;
				default: break;
			}
			}
			while(ch!=0);
		
		}
		else
		{
			cout<<"Program initialization failed, please check configuration parameters and network environment!"<<endl;
		}
	
	}
	else
	{
		cout<<"Password settings are mistaken!"<<endl;
	}
	system("PAUSE");
	return 0;
}

