
#include <stdio.h>

int init();
int EntPwd(char * pass,const int contn);
void ChDirection(char iflag);